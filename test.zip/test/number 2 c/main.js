function pushData() {
	let view = document.getElementById("items");
	let newTd = document.createElement("li");
	var inputText = document.getElementById("inputText").value;
	var node = document.createTextNode(inputText);
	newTd.appendChild(node);
	view.appendChild(newTd);
}
