function changeImage(){
    let displayImage = document.getElementById("img1")
    if(displayImage.src.match("image1.jpg")){
        displayImage.src = "image2.jpg"
    } else {
        displayImage.src = "image1.jpg"
        
    } 
}